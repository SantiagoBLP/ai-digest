# Artificial Intelligence and Genetics Can Help Farmers Grow Corn With Less Fertilizer

**Source:** [ScienceDaily](https://www.sciencedaily.com/releases/2025/05/250514164325.htm)  
**Cited Paper:** [http://dx.doi.org/10.1093/plcell/koaf093](http://dx.doi.org/10.1093/plcell/koaf093)

---

## 🔍 Summary
May 14, 2025 —Scientists are using artificial intelligence to determine which genes collectively govern nitrogen use efficiency in plants such as corn, with the goal of helping farmers improve their crop yields ...

---

## 📄 Abstract from Cited Research
nan

---

*Auto-generated science digest post.*
