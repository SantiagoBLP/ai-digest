# Study Shows Vision-Language Models Can't Handle Queries With Negation Words

**Source:** [ScienceDaily](https://www.sciencedaily.com/releases/2025/05/250514165630.htm)  
**Cited Paper:** [http://dx.doi.org/10.48550/arXiv.2501.09425](http://dx.doi.org/10.48550/arXiv.2501.09425)

---

## 🔍 Summary
May 14, 2025 —Researchers found that vision-language models, widely used to analyze medical images, do not understand negation words like 'no' and 'not.' This could cause them to fail ...

---

## 📄 Abstract from Cited Research
nan

---

*Auto-generated science digest post.*
