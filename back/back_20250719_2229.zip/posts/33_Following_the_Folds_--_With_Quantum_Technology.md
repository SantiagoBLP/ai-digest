# Following the Folds -- With Quantum Technology

**Source:** [ScienceDaily](https://www.sciencedaily.com/releases/2025/05/250514175424.htm)  
**Cited Paper:** [nan](nan)

---

## 🔍 Summary
May 14, 2025 —The connection between a crumpled sheet of paper and quantum technology: A research team at the EPFL in Lausanne (Switzerland) and the University of Konstanz (Germany) uses topology in microwave ...

---

## 📄 Abstract from Cited Research
nan

---

*Auto-generated science digest post.*
