# AI Meets Game Theory: How Language Models Perform in Human-Like Social Scenarios

**Source:** [ScienceDaily](https://www.sciencedaily.com/releases/2025/05/250528132456.htm)  
**Cited Paper:** [http://dx.doi.org/10.1038/s41562-025-02172-y](http://dx.doi.org/10.1038/s41562-025-02172-y)

---

## 🔍 Summary
May 30, 2025 —Large language models (LLMs) -- the advanced AI behind tools like ChatGPT -- are increasingly integrated into daily life, assisting with tasks such ...

---

## 📄 Abstract from Cited Research
nan

---

*Auto-generated science digest post.*
