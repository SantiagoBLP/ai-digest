# World's First Petahertz-Speed Phototransistor in Ambient Conditions

**Source:** [ScienceDaily](https://www.sciencedaily.com/releases/2025/05/250519204533.htm)  
**Cited Paper:** [http://dx.doi.org/10.1038/s41467-025-59675-5](http://dx.doi.org/10.1038/s41467-025-59675-5)

---

## 🔍 Summary
May 19, 2025 —Researchers demonstrated a way to to manipulate electrons using pulses of light that last less than a trillionth of a second to record electrons bypassing a physical barrier almost instantaneously -- ...

---

## 📄 Abstract from Cited Research
nan

---

*Auto-generated science digest post.*
